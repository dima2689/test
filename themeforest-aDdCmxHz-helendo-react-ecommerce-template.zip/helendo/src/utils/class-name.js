export const className = (...classes) => classes.filter(Boolean).join('');
