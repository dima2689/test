---
id: 'featured-product-02'
subTitle: 'Featured Product'
title: 'Table Wood Pine'
excerpt: 'Excepteur sint occaecat cupidatat non proident, sunt in culpaqui <br/> officia deserunt mollit anim id est laborum.'
image: '/images/featured-product/table-wood-pine.png'
altImage: 'Featured Product Image'
path: '/products/table-wood-pine'
buttonText: 'Only $50'
---
