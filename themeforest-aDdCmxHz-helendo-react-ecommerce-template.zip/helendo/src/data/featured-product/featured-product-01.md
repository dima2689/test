---
id: 'featured-product-01'
subTitle: 'Featured Product'
title: 'Nancy Chair'
excerpt: 'When an unknown printer took a galley of type and scrambled it to make a type specimen book. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia.'
image: '/images/featured-product/nancy-chair.png'
altImage: 'Featured Product Image'
path: '/products/nancy-chair'
buttonText: 'Only $90'
---
