---
authTabMenu:
    [
        { id: 'auth-menu-01', authMenuName: 'Login', tabStateNo: 1 },
        { id: 'auth-menu-02', authMenuName: 'Our Register', tabStateNo: 2 },
    ]
---
