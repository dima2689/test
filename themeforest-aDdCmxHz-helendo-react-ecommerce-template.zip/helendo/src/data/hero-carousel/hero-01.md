---
id: 'hero-carousel-01'
heroBG: 'hero-bg hero-carousel-bg-01'
title: 'Alarm Clock <br /> Carbon'
desc: ' Many desktop publishing packages and web page editors now use  <br /> Lorem Ipsum as their default model text'
---
