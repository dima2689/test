---
id: 'hero-carousel-02'
heroBG: 'hero-bg hero-carousel-bg-02'
title: 'Angel <br /> Wooden Chair'
desc: ' Many desktop publishing packages and web page editors now use  <br /> Lorem Ipsum as their default model text'
---
