---
id: 'product-16'
title: 'Drinking Glasses'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
homeCollectionImg: '600x429.png'
altImage: 'Product Image'
price: 21
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 515
category: 'decoration'
availability: 'in-stock'
size: 'large'
color: 'yellow'
tag: 'table'
isFeatured: true
---
