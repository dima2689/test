---
id: 'product-04'
title: 'Smooth Disk'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
altImage: 'Product Image'
price: 46
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 507
category: 'accessory'
availability: 'in-stock'
size: 'medium'
color: 'yellow'
tag: 'accessories'
isFeatured: true
---
