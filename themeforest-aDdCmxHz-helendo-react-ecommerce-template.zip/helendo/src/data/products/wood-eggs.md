---
id: 'product-15'
title: 'Wood Eggs'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
categoryBannerImg: '580x213.jpg'
altImage: 'Product Image'
price: 19
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 514
category: 'decoration'
availability: 'in-stock'
size: 'small'
color: 'yellow'
tag: 'table'
isFeatured: true
---
