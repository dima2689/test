---
id: 'product-10'
title: 'Wooden Box'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
homeCollectionImg: '585x585.jpg'
altImage: 'Product Image'
price: 27
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 511
category: 'accessory'
availability: 'in-stock'
size: 'small'
color: 'red'
tag: 'accessories'
isFeatured: true
---
