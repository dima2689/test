---
id: 'product-02'
title: 'Teapot with black tea'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
altImage: 'Product Image'
price: 25
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 509
category: 'accessory'
availability: 'in-stock'
size: 'small'
color: 'black'
tag: 'accessories'
isFeatured: true
---
