---
id: 'product-09'
title: 'Living Room & Bedroom Lights'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
altImage: 'Product Image'
price: 45
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 504
category: 'accessory'
availability: 'in-stock'
size: 'large'
color: 'gray'
tag: 'accessories'
isFeatured: true
---
