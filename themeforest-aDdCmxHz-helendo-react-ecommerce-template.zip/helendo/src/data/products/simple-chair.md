---
id: 'product-03'
title: 'Simple Chair'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
altImage: 'Product Image'
price: 40
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
soldOutSticker: 'Out of Stock'
sku: 506
category: 'furniture'
availability: 'out-of-stock'
size: 'large'
color: 'yellow'
tag: 'chair'
isFeatured: true
---
