---
id: 'product-11'
title: 'Unique Decoration'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
altImage: 'Product Image'
price: 15
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 510
category: 'decoration'
availability: 'in-stock'
size: 'medium'
color: 'red'
tag: 'deco'
isFeatured: true
---
