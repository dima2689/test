---
id: 'product-12'
title: 'Animi Dolor Pariatur'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
altImage: 'Product Image'
price: 10
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 500
category: 'accessory'
availability: 'in-stock'
size: 'large'
color: 'green'
tag: 'accessories'
isFeatured: true
---
