---
id: 'product-17'
title: 'Wooden Cups'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
homeCollectionImg: '400x450.png'
altImage: 'Product Image'
price: 29
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 516
category: 'decoration'
availability: 'in-stock'
size: 'large'
color: 'green'
tag: 'table'
isFeatured: true
---
