---
id: 'product-08'
title: 'High Quality Glass Bottle'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
altImage: 'Product Image'
price: 35
discountPrice: 30.1
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
bestSellerSticker: 'Sale'
offerSticker: '-14%'
sku: 503
category: 'accessory'
availability: 'in-stock'
size: 'medium'
color: 'black'
tag: 'glass'
isFeatured: true
---
