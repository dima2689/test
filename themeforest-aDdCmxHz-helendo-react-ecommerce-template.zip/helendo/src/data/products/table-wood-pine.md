---
id: 'product-06'
title: 'Table Wood Pine'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
categoryBannerImg: '580x213.jpg'
altImage: 'Product Image'
price: 50
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 508
category: 'furniture'
availability: 'in-stock'
size: 'large'
color: 'red'
tag: 'table'
isFeatured: true
---
