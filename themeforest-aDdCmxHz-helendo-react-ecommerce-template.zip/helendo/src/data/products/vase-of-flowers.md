---
id: 'product-14'
title: 'Vase Of Flowers'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
categoryBannerImg: '285x396.jpg'
altImage: 'Product Image'
price: 77
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 513
category: 'decoration'
availability: 'in-stock'
size: 'medium'
color: 'gray'
tag: 'table'
isFeatured: true
---
