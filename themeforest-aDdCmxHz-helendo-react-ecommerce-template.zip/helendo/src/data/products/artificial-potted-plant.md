---
id: 'product-01'
title: 'Artificial potted plant'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
altImage: 'Product Image'
price: 40
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
soldOutSticker: 'Out of Stock'
sku: 502
category: 'decoration'
availability: 'out-of-stock'
size: 'medium'
color: 'black'
tag: 'deco'
isFeatured: true
---
