---
id: 'product-19'
title: 'Dark Green Jug'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
homeCollectionImg: '600x600.jpg'
altImage: 'Product Image'
price: 19
discountPrice: 17.1
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
bestSellerSticker: 'Sale'
offerSticker: '-10%'
sku: 518
category: 'decoration'
availability: 'in-stock'
size: 'large'
color: 'green'
tag: 'table'
isFeatured: true
---
