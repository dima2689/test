---
id: 'product-13'
title: 'Helen Chair'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
categoryBannerImg: '568x389.jpg'
altImage: 'Product Image'
price: 92
discountPrice: 69.5
sku: 512
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
bestSellerSticker: 'Sale'
offerSticker: '-25%'
category: 'decoration'
availability: 'in-stock'
size: 'medium'
color: 'yellow'
tag: 'table'
isFeatured: true
---
