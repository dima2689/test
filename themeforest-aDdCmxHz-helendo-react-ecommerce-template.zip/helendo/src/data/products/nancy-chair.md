---
id: 'product-05'
title: 'Nancy Chair'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
homeCollectionImg: '570x570.png'
altImage: 'Product Image'
price: 90
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 505
category: 'furniture'
availability: 'in-stock'
size: 'large'
color: 'black'
tag: 'chair'
isFeatured: true
---
