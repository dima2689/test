---
id: 'product-07'
title: 'Art Deco Home'
xsImage: '74x74.jpg'
smImage: '300x300.jpg'
mdImage: '585x585.jpg'
categoryBannerImg: '285x396.jpg'
altImage: 'Product Image'
price: 30
desc: 'At vero accusamus et iusto odio dignissimos blanditiis praesentiums dolores molest.'
sku: 501
category: 'decoration'
availability: 'in-stock'
size: 'large'
color: 'yellow'
tag: 'deco'
isFeatured: true
---
