---
cartThList:
    [
        {
            id: 'cart-th-01',
            thCName: 'font-medium product-name py-3',
            thName: 'Product',
        },
        {
            id: 'cart-th-02',
            thCName: 'font-medium product-price py-3',
            thName: 'Price',
        },
        { id: 'cart-th-03', thCName: 'font-medium py-3', thName: 'Quantity' },
        { id: 'cart-th-04', thCName: 'font-medium py-3', thName: 'Total' },
        {
            id: 'cart-th-05',
            thCName: 'font-medium py-3 sr-only-custom',
            thName: 'Item Remove',
        },
    ]
couponTitle: 'Coupon Discount'
couponDesc: 'Enter your coupon code if you have one.'
couponBtnText: 'Apply coupon'
shopPageBtnText: 'Continue Shopping'
clearCartBtnText: 'Clear cart'
subtotalInfo:
    [
        {
            id: subtotal-info-01,
            title: 'Subtotal:',
            withBorder: 'border-b border-[#cdcdcd] pb-[16px] mb-[17px]',
        },
        { id: subtotal-info-02, title: 'Total:', withBorder: '' },
    ]
proceedBtnText: 'Proceed to checkout'
---
