---
title: 'Helendo Store'
desc: 'When you start with a portrait and search for a pure
    form, a clear volume, through successive eliminations,
    you arrive inevitably at the egg. Likewise, starting
    with the egg and following the same process in reverse,
    one finishes with the portrait.'
modalImageOne: '/images/video-banner/1.jpg'
imgAlt: 'Video Modal'
---
