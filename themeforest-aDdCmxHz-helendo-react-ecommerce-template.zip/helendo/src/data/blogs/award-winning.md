---
id: 'blog-01'
title: 'Intelligent, award-winning product of the designer Thomas in 2022.'
mediumImage: '374x243.jpg'
masonry: '366x423.jpg'
largeImage: '854x491.jpg'
extraLargeImage: '1146x745.jpg'
altImage: 'Award Winning'
date: '2023-10-23'
author: 'Admin'
categoryItem: 'furniture'
desc: 'Contrary to popular belief, Lorem Ipsum indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in…'
category:
    - all | <span>(09)</span>
    - furniture | <span>(02)</span>
tag:
    - all
    - chair
blockquoteDesc: 'Dalena dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore etyt dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi utino aliquip ex ea commodo consequat.'
singleImgOne: '/images/rich-text/1-570x327.jpg'
singleImgTwo: '/images/rich-text/2-570x327.jpg'
singleImgAlt: 'Single Image'
isFeatured: true
---
