---
categoryBannerItems:
    [
        { id: 'product-07', CName: 'md:col-span-3 col-span-12' },
        { id: 'product-13', CName: 'md:col-span-6 col-span-12' },
        { id: 'product-14', CName: 'md:col-span-3 col-span-12' },
        { id: 'product-15', CName: 'md:col-span-6 col-span-12' },
        { id: 'product-06', CName: 'md:col-span-6 col-span-12' },
    ]
---
