---
newArrivalItemsTwo:
    [
        { id: 'product-16', CName: 'newarrival-item-two' },
        { id: 'product-17', CName: 'newarrival-item-two' },
        { id: 'product-19', CName: 'newarrival-item-two' },
        { id: 'product-05', CName: 'newarrival-reverse-item' },
        { id: 'product-18', CName: 'newarrival-item-two' },
        { id: 'product-10', CName: 'newarrival-item-two' },
    ]
---
