---
wishlistThList:
    [
        {
            id: 'wishlist-th-01',
            thCName: 'font-medium product-name py-3',
            thName: 'Product',
        },
        {
            id: 'wishlist-th-02',
            thCName: 'font-medium product-price py-3',
            thName: 'Unit Price',
        },
        {
            id: 'wishlist-th-03',
            thCName: 'font-medium py-3 sr-only-custom',
            thName: 'Buy Now',
        },
        {
            id: 'wishlist-th-04',
            thCName: 'font-medium py-3 sr-only-custom',
            thName: 'Item Remove',
        },
    ]
clearWishlistBtnText: 'Clear wishlist'
---
