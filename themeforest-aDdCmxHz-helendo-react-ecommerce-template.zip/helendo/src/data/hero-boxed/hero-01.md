---
id: 'hero-boxed-01'
image: '/images/hero/home-boxed/1.png'
imageAlt: 'Slide Image'
subtitle: 'Helendo Store'
title: 'Hailey <br /> Wooden Chair'
---
