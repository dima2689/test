---
id: 'hero-boxed-02'
image: '/images/hero/home-boxed/2.png'
imageAlt: 'Slide Image'
subtitle: 'Helendo Store'
title: 'Hailey <br /> Wooden Chair'
---
