---
singleContactInfo:
    [
        {
            id: 01,
            infoIcon: 'IoStopwatchOutline',
            title: 'Open houses',
            desc: 'Mon – Fri : 8:30 – 18:00  <br/> Sat – Sun : 9:00 – 17:00',
        },
        {
            id: 02,
            infoIcon: 'IoCallOutline',
            title: 'Phone number',
            desc: '(504) 586 256 23  <br/> (306) 574 326 56',
        },
        {
            id: 03,
            infoIcon: 'IoMailOpenOutline',
            title: 'Our email',
            desc: 'office@helendo.com  <br/> Info@helendo.com',
        },
        {
            id: 04,
            infoIcon: 'IoLocationOutline',
            title: 'Our location',
            desc: '1102 Helen Estates, Guys  <br/> Store, San Diego, USA.',
        },
    ]
formTitle: 'Get in touch'
formDesc: 'Write us a letter !'
infoTitle: 'Our address'
infoDesc: 'Duis aute irure dolor in reprehenderit ioluptate velit esse cillum dolore pariatur.'
contactAddress: '1102 Helen Estates, Guys Store, San Diego, USA. <br/> (693) 650-2389 <br/> office@helendo.com'
socialTitle: 'Follow Us On Social'
socialList:
    [
        { id: 01, socialIcon: 'IoLogoGoogle', path: 'https://www.google.com/' },
        { id: 02, socialIcon: 'IoLogoTumblr', path: 'https://www.tumblr.com/' },
        { id: 03, socialIcon: 'IoLogoTwitter', path: 'https://twitter.com/' },
    ]
---
