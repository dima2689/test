---
title: 'Coming Soon...'
desc: 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t slightly believable.'
countTitle: 'NEW STORE WE BE LUNCHED IN:'
socialTitle: 'FOLLOW US:'
socialList:
    [
        { id: 01, socialIcon: 'IoLogoGoogle', path: 'https://www.google.com/' },
        { id: 02, socialIcon: 'IoLogoTumblr', path: 'https://www.tumblr.com/' },
        { id: 03, socialIcon: 'IoLogoTwitter', path: 'https://twitter.com/' },
    ]
---
