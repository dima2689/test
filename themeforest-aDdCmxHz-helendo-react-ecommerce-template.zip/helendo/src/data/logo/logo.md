---
id: 'logo-01'
darkLogo: '/images/logo/dark-logo.png'
darkLogoAlt: 'Header Logo'
---
