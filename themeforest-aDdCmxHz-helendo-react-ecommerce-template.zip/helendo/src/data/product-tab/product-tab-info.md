---
tabList:
    [
        {
            id: 'product-tab-01',
            title: 'All Products',
            filterValue: 'all-products',
        },
        { id: 'product-tab-02', title: 'Accessory', filterValue: 'accessory' },
        {
            id: 'product-tab-03',
            title: 'Decoration',
            filterValue: 'decoration',
        },
        { id: 'product-tab-04', title: 'Furniture', filterValue: 'furniture' },
    ]
---
