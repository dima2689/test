---
videoBanner: '/images/about/video-banner.jpg'
videoBannerAlt: 'Video Banner'
singleSupportInfo:
    [
        {
            id: 'info-01',
            infoIcon: 'IoBagHandleOutline',
            title: 'Shop online',
            desc: 'There are many variations pasbut the majority have suffered.',
        },
        {
            id: 'info-02',
            infoIcon: 'IoLogoPaypal',
            title: 'Payment methods',
            desc: 'Letraset sheets containing Lorem Ipsum publishing software.',
        },
        {
            id: 'info-03',
            infoIcon: 'IoNavigateOutline',
            title: 'Free shipping',
            desc: 'when an unknown printer took a make a type book.',
        },
        {
            id: 'info-04',
            infoIcon: 'IoStopwatchOutline',
            title: 'Return policy',
            desc: 'Various versions have evolved over the years purpose.',
        },
    ]
perfectionTitle: 'Functionality meets perfection'
perfectionDesc: 'But I must explain to you how all this mistaken idea of denouncing sure and praising pain was born and I will give you a complete at the system, expound the actual teachings of the great of the truth, the human happiness was born. teachings of the great of the truth.'
aboutBannerAlt: 'About Banner'
aboutBannerOne: '/images/about/banner/1-780x770.jpg'
aboutBannerTwo: '/images/about/banner/2-380x380.jpg'
aboutBannerThree: '/images/about/banner/3-380x380.jpg'
aboutBannerFour: '/images/about/banner/4-380x380.jpg'
aboutBannerFive: '/images/about/banner/5-780x380.jpg'
addressTitleOne: 'New York'
addressDescOne: '2954 Golden Estates, Guys Store, New York, USA. <br/> (571) 400-1255 <br/> info@helendo.com'
addressTitleTwo: 'San Diego'
addressDescTwo: '1102 Helen Estates, Guys Store, San Diego, USA. <br/> (571) 400-1255 <br/> office@helendo.com'
---
