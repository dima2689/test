---
newArrivalItems:
    [
        { id: 'product-08' },
        { id: 'product-11' },
        { id: 'product-03' },
        { id: 'product-05' },
        { id: 'product-07' },
        { id: 'product-01' },
    ]
---
