---
id: 'hero-collection-01'
subtitle: 'Helendo store'
title: 'Spice jars'
desc: ' There are many variations of passages of Lorem Ipsum available, but <br /> the majority have suffered alteration in some form.'
image: '/images/hero/home-collection/1.png'
imageAlt: 'Slide Image'
---
