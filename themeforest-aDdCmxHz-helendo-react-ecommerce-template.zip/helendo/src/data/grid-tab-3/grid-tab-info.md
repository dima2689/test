---
gridTabList:
    [
        {
            id: 'grid-tab-list-01',
            gridColumns: 'grid-04',
            gridColumnImg: '/images/grid-icon/columns-04.png',
            gridImgAlt: 'Grid Image',
            tabStateNo: 1,
        },
        {
            id: 'grid-tab-list-02',
            gridColumns: 'grid-05',
            gridColumnImg: '/images/grid-icon/columns-05.png',
            gridImgAlt: 'Grid Image',
            tabStateNo: 2,
        },
        {
            id: 'grid-tab-list-03',
            gridColumns: 'grid-06',
            gridColumnImg: '/images/grid-icon/columns-06.png',
            gridImgAlt: 'Grid Image',
            tabStateNo: 3,
        },
    ]
---
