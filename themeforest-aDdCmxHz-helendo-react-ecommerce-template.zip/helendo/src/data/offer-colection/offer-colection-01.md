---
id: 'offer-colection-01'
title: 'Deco Collection <span class="offer">50% OFF</span>'
desc: 'The standard chunk of Lorem Ipsum used since the 1500s is reproduced for those. Sections 1.10.32 and 1.10.33 from “de Finibus Bonorum et Malorum'
---
